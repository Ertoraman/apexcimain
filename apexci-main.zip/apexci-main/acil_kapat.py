import pymongo
import threading
from cryptography.fernet import Fernet
from binance.client import Client
from datetime import datetime

# --- GÜVENLİK VE VERİTABANI ---
MASTER_KEY = b'0MxMmK7vMHEqKqGMwLYQe_DIejF9fw098cv2OwGTh74='
cipher = Fernet(MASTER_KEY)

client_db = pymongo.MongoClient("mongodb://localhost:27017/")
db = client_db["apexprotocol"]
users_col = db["users"]
logs_col = db["logs"]

def tum_pozisyonlari_kapat(kullanici):
    """Kullanıcının Binance Futures hesabındaki TÜM açık pozisyonları kapatır."""
    try:
        api_key = cipher.decrypt(kullanici["binance_api"].encode()).decode()
        api_secret = cipher.decrypt(kullanici["binance_secret"].encode()).decode()
        binance = Client(api_key, api_secret)

        # Kullanıcının tüm vadeli pozisyon bilgilerini al
        pos_info = binance.futures_position_information()
        
        kapatilan_semboller = []

        for pos in pos_info:
            amt = float(pos['positionAmt'])
            symbol = pos['symbol']
            
            # Eğer miktar 0 değilse açık pozisyon vardır
            if amt != 0:
                side = "SELL" if amt > 0 else "BUY"
                abs_amt = abs(amt)
                
                print(f"   [!] {kullanici['user_name']}: {symbol} ({amt}) kapatılıyor...")
                
                # Market emri ile pozisyonu sıfırla
                binance.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type='MARKET',
                    quantity=abs_amt,
                    reduceOnly=True
                )
                kapatilan_semboller.append(symbol)
        
        if kapatilan_semboller:
            logs_col.insert_one({
                "user": kullanici["user_name"],
                "action": "TOTAL_PANIC_CLOSE",
                "symbols": kapatilan_semboller,
                "time": datetime.now()
            })
            print(f"   [OK] {kullanici['user_name']} için {len(kapatilan_semboller)} pozisyon kapatıldı.")
        
    except Exception as e:
        print(f"   [X] Hata ({kullanici['user_name']}): {e}")

def genel_temizlik_baslat():
    print(f"\n--- !!! TAM KAPSAMLI ACİL KAPATMA BAŞLATILDI ({datetime.now()}) !!! ---")
    
    # Aktif ve süresi dolmamış kullanıcıları çek
    aktif_kullanicilar = list(users_col.find({
        "is_active": True,
        "expiry_date": {"$gt": datetime.now()}
    }))

    if not aktif_kullanicilar:
        print("Kapatılacak aktif kullanıcı bulunamadı.")
        return

    print(f"[*] {len(aktif_kullanicilar)} kullanıcı için tüm tahta temizleniyor...")

    threads = []
    for user in aktif_kullanicilar:
        t = threading.Thread(target=tum_pozisyonlari_kapat, args=(user,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print("\n--- İŞLEM TAMAMLANDI: TÜM KULLANICILARIN TÜM POZİSYONLARI KAPATILDI ---")

if __name__ == "__main__":
    print("DİKKAT: Bu işlem tüm kullanıcıların istisnasız TÜM pozisyonlarını kapatacaktır!")
    onay = input("Onaylıyor musunuz? (evet/hayır): ")
    if onay.lower() == "evet":
        genel_temizlik_baslat()
    else:
        print("İşlem iptal edildi.")
