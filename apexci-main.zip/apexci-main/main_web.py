from fastapi import FastAPI, Request, Form, Response, Cookie
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from pymongo import MongoClient
from datetime import datetime, timedelta, timezone
import uvicorn
import requests
import hashlib
import hmac
import uuid
import ccxt

app = FastAPI()
templates = Jinja2Templates(directory="templates")

# --- 🗄️ MONGO DB BAĞLANTISI ---
client = MongoClient("mongodb://localhost:27017/")
db = client["apexprotocol"]
users_col = db["users"]
signals_col = db["signal"]
orders_col = db["shopier_orders"] 
user_logs_col = db["user_logs"]
mail_list_col = db["mail_list"]

# --- ⚙️ SHOPIER AYARLARI ---
SHOPIER_API_TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9..." # Shopier API Token bilginiz

# --- 🛠️ YARDIMCI FONKSİYONLAR ---
def hash_password(password: str):
    return hashlib.sha256(password.encode('utf-8')).hexdigest()

def verify_and_setup_binance(api_key, secret_key):
    """API anahtarlarını doğrular ve Hedge Mode'u otomatik aktif eder."""
    try:
        exchange = ccxt.binance({
            'apiKey': api_key,
            'secret': secret_key,
            'options': {'defaultType': 'future'}
        })
        exchange.fetch_balance()
        res = exchange.fapiPrivateGetPositionSideDual()
        if not res.get('dualSidePosition'):
            exchange.fapiPrivatePostPositionSideDual({'dualSidePosition': 'true'})
        return hashlib.sha256(api_key.encode()).hexdigest()
    except Exception as e:
        print(f"Binance Doğrulama Hatası: {e}")
        return None

def get_current_user(request: Request):
    session_token = request.cookies.get("session_token")
    if session_token:
        return users_col.find_one({"session_token": session_token})
    return None

def parse_db_time(db_time):
    if not db_time: return None
    if isinstance(db_time, datetime): return db_time
    if isinstance(db_time, dict) and "$date" in db_time:
        try: return datetime.fromisoformat(db_time["$date"].replace('Z', '+00:00')).replace(tzinfo=None)
        except: return None
    return None

# --- 🌐 GENEL ROTALAR ---

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    user = get_current_user(request)
    return templates.TemplateResponse(request, "index.html", {"request": request, "user": user})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    return templates.TemplateResponse(request, "login.html", {"request": request})

@app.post("/login")
async def login_post(request: Request, response: Response, username: str = Form(...), password: str = Form(...)):
    user = users_col.find_one({"username": username.strip().lower(), "password": hash_password(password)})
    
    if user:
        session_token = str(uuid.uuid4())
        users_col.update_one({"_id": user["_id"]}, {"$set": {"session_token": session_token}})
        
        response = RedirectResponse(url="/app", status_code=303)
        response.set_cookie(key="session_token", value=session_token, httponly=True)
        return response
        
    return RedirectResponse(url="/login?error=invalid_credentials", status_code=303)

@app.post("/register")
async def register(request: Request, username: str = Form(...), email: str = Form(...), 
                   password: str = Form(...), api: str = Form(...), secret: str = Form(...), miktar: float = Form(50.0)):
    username = username.strip().lower()
    if users_col.find_one({"$or": [{"username": username}, {"email": email}]}):
        return templates.TemplateResponse(request, "index.html", {"request": request, "error_detail": "Kullanıcı adı veya e-posta zaten kullanımda."})
    
    account_hash = verify_and_setup_binance(api, secret)
    if not account_hash:
        return templates.TemplateResponse(request, "index.html", {"request": request, "error_detail": "Binance API geçersiz veya Hedge Mode açılamadı."})

    session_token = str(uuid.uuid4())
    users_col.insert_one({
        "username": username, "email": email, "password": hash_password(password),
        "api_key": api, "secret_key": secret, "miktar": miktar, "account_hash": account_hash,
        "bot_status": "active", "subscription_end": datetime.now() + timedelta(days=10),
        "created_at": datetime.now(), "session_token": session_token
    })

    response = RedirectResponse(url="/app", status_code=302)
    response.set_cookie(key="session_token", value=session_token, httponly=True)
    return response

@app.post("/join-waitlist")
async def join_waitlist(email: str = Form(...)):
    if email:
        if not mail_list_col.find_one({"email": email}):
            mail_list_col.insert_one({
                "email": email,
                "registered_at": datetime.now()
            })
        return JSONResponse(content={"status": "success", "message": "Kaydınız başarıyla alındı."})
    return JSONResponse(content={"status": "error", "message": "Geçersiz e-posta."}, status_code=400)

@app.get("/api/sinyaller")
async def get_signals():
    try:
        one_day_ago = datetime.now() - timedelta(hours=24)
        closed_signals = list(signals_col.find({"action": {"$in": ["CLOSE", "MIGRATE"]}}).sort("time", -1).limit(50))
        
        total_percentage = 0.0
        signals_list = []
        
        for s in closed_signals:
            pt = parse_db_time(s.get("time"))
            pnl_val = float(s.get("pnl", 0.0))
            pnl_perc = (pnl_val / 50.0) * 100 
            
            if pt and pt >= one_day_ago:
                total_percentage += abs(pnl_perc)
                
            if len(signals_list) < 5:
                signals_list.append({
                    "symbol": str(s.get("symbol") or s.get("from_sym", "")).split(":")[0],
                    "side": s.get("side", "LONG"),
                    "pnl_perc": round(abs(pnl_perc), 2),
                    "time": (pt + timedelta(hours=3)).strftime("%H:%M") if pt else "--:--"
                })
                
        return {
            "pnl_24h": round(total_percentage, 2),
            "recent_signals": signals_list
        }
    except Exception as e:
        return {"pnl_24h": 0.0, "recent_signals": []}

@app.get("/logout")
async def logout(response: Response):
    response = RedirectResponse(url="/", status_code=303)
    response.delete_cookie("session_token")
    return response

# --- 🚀 PANEL (DASHBOARD) ROTALARI ---

@app.get("/app", response_class=HTMLResponse)
async def app_page(request: Request):
    user = get_current_user(request)
    if not user: return RedirectResponse(url="/", status_code=302)
    return templates.TemplateResponse(request, "trading_app.html", {"request": request, "user": user})

@app.post("/bot_durum_guncelle")
async def update_bot_status(request: Request, islem: str = Form(...)):
    user = get_current_user(request)
    if not user: return RedirectResponse(url="/", status_code=302)

    if user.get("subscription_end") and user["subscription_end"] < datetime.now():
        return RedirectResponse(url="/app?error=abonelik_bitti", status_code=303)

    new_status = "active" if islem == "baslat" else "stopped"
    users_col.update_one({"_id": user["_id"]}, {"$set": {"bot_status": new_status}})
    return RedirectResponse(url="/app", status_code=303)

@app.post("/api_guncelle")
async def update_api(request: Request, api_key: str = Form(...), secret_key: str = Form(...)):
    user = get_current_user(request)
    if not user: return RedirectResponse(url="/app", status_code=303)

    account_hash = verify_and_setup_binance(api_key, secret_key)
    if not account_hash:
        return RedirectResponse(url="/app?error=gecersiz_api", status_code=303)

    users_col.update_one({"_id": user["_id"]}, {"$set": {"api_key": api_key, "secret_key": secret_key, "account_hash": account_hash}})
    return RedirectResponse(url="/app?success=api_guncellendi", status_code=303)

# --- 💳 SHOPIER SİPARİŞ KONTROL VE ABONELİK UZATMA MODÜLÜ ---
@app.post("/abonelik_uzat")
async def abonelik_uzat(request: Request, siparis_no: str = Form(...)):
    user = get_current_user(request)
    if not user: return RedirectResponse(url="/", status_code=302)
    
    siparis_no = siparis_no.strip()
    
    # 1. Bu sipariş numarası daha önce veritabanında kullanılmış mı?
    if orders_col.find_one({"siparis_no": siparis_no}):
        return RedirectResponse(url="/app?error=siparis_zaten_kullanilmis", status_code=303)
    
    # 2. Shopier API ile Gerçek Sipariş ve Ödeme Doğrulama Kontrolü
    siparis_gecerli = False
    try:
        headers = {
            "Authorization": f"Bearer {SHOPIER_API_TOKEN}",
            "Content-Type": "application/json"
        }
        api_url = f"https://www.shopier.com/api/v1/orders/{siparis_no}"
        resp = requests.get(api_url, headers=headers, timeout=5)
        
        if resp.status_code == 200:
            data = resp.json()
            # Sipariş durumu başarılı veya ödenmiş olarak dönüyorsa onay ver
            if data.get("status") == "success" or data.get("payment_status") == "success":
                siparis_gecerli = True
        else:
            # API yanıt vermezse veya sipariş bulunamazsa geçersiz kabul et
            siparis_gecerli = False
    except Exception as e:
        print(f"Shopier API Sorgu Hatası: {e}")
        siparis_gecerli = False

    # Eğer sipariş Shopier'de doğrulanmadıysa işlemi reddet
    if not siparis_gecerli:
        return RedirectResponse(url="/app?error=gecersiz_veya_odenmemis_siparis", status_code=303)
    
    # 3. Süre Uzatma İşlemi (30 Gün Ekle)
    simdi = datetime.now()
    mevcut_bitis = user.get("subscription_end")
    
    if isinstance(mevcut_bitis, datetime) and mevcut_bitis > simdi:
        yeni_bitis = mevcut_bitis + timedelta(days=30)
    else:
        yeni_bitis = simdi + timedelta(days=30)
        
    # 4. Siparişi işlendi olarak kaydet ve kullanıcının süresini güncelle
    orders_col.insert_one({
        "siparis_no": siparis_no,
        "username": user["username"],
        "tarih": simdi
    })
    
    users_col.update_one(
        {"_id": user["_id"]},
        {"$set": {"subscription_end": yeni_bitis, "bot_status": "active"}}
    )
    
    return RedirectResponse(url="/app?success=abonelik_uzatildi", status_code=303)

@app.get("/api/panel_verileri")
async def panel_api(request: Request):
    user = get_current_user(request)
    if not user: return {"error": "unauth"}

    exp = user.get("subscription_end")
    bitis_tarihi = exp.strftime("%d.%m.%Y %H:%M") if exp else "Süresiz"
    kalan_gun = (exp - datetime.now()).days if exp and exp > datetime.now() else 0

    bakiye = "0.00"
    if user.get("api_key") and user.get("secret_key"):
        try:
            ex = ccxt.binance({'apiKey': user["api_key"], 'secret': user["secret_key"], 'options': {'defaultType': 'future'}})
            bal = ex.fetch_balance()
            bakiye = str(round(float(bal['total'].get('USDT', 0)), 2))
        except: pass

    logs = list(user_logs_col.find({"username": user["username"]}).sort("time", -1).limit(20))
    processed_logs = []
    for log in logs:
        pt = parse_db_time(log.get("time"))
        processed_logs.append({
            "type": log.get("type", "success"),
            "symbol": log.get("symbol", "SİSTEM"),
            "message": log.get("message", ""),
            "time": (pt + timedelta(hours=3)).strftime("%d/%m %H:%M") if pt else "--:--"
        })

    return {
        "bot_status": user.get("bot_status", "inactive"),
        "expires_at": f"{bitis_tarihi} ({kalan_gun} Gün)",
        "kalan_gun": kalan_gun,
        "balance": f"${bakiye}",
        "miktar": user.get("miktar", 50.0),
        "logs": processed_logs
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=80)
