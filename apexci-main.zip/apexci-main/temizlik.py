import os
import psutil
import shutil

def tam_temizlik_yap():
    suanki_pid = os.getpid()
    oldurulen_bot_sayisi = 0

    print("--- 1. ADIM: Arkaplandaki Tüm Botları Kapatma ---")
    # İşletim sistemindeki tüm süreçleri tara
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            # Kendi çalıştırdığımız bu temizlik dosyası hariç tüm python.exe süreçlerini bul ve zorla kapat
            if proc.info['name'] and 'python' in proc.info['name'].lower():
                if proc.info['pid'] != suanki_pid:
                    proc.kill()
                    oldurulen_bot_sayisi += 1
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass
            
    print(f"Toplam {oldurulen_bot_sayisi} adet askıda kalan Python botu sonlandırıldı.\n")

    print("--- 2. ADIM: Artık Dosyaları ve Önbelleği Temizleme ---")
    temizlenen_dosya_sayisi = 0
    mevcut_dizin = os.getcwd() # Scriptin çalıştığı klasörü ve alt klasörleri tarar

    for root, dirs, files in os.walk(mevcut_dizin):
        # Python'un oluşturduğu eski önbellek klasörlerini tamamen sil
        for dir_name in dirs:
            if dir_name == "__pycache__":
                dir_path = os.path.join(root, dir_name)
                try:
                    shutil.rmtree(dir_path)
                    print(f"Silindi (Önbellek Klasörü): {dir_path}")
                except:
                    pass

        # Askıda kalan geçici dosyaları (.tmp) ve derlenmiş python dosyalarını (.pyc) sil
        for file in files:
            if file.endswith((".pyc", ".tmp")): 
                file_path = os.path.join(root, file)
                try:
                    os.remove(file_path)
                    temizlenen_dosya_sayisi += 1
                except:
                    pass

    print(f"Toplam {temizlenen_dosya_sayisi} adet artık dosya temizlendi.\n")
    print("Sistem başarıyla temizlendi. Botlarını artık güvenle yeniden başlatabilirsin.")

if __name__ == "__main__":
    tam_temizlik_yap()
