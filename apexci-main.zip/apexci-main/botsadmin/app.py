from flask import Flask, render_template, jsonify
import json, pymongo, os, ccxt
from collections import defaultdict

app = Flask(__name__)
exchange = ccxt.binance({'options': {'defaultType': 'future'}})

# MongoDB Bağlantısı
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["apexprotocol"]
signals_col = db["signal"]

def get_live_data():
    active_items = list(signals_col.find({"action": {"$in": ["OPEN", "open"]}}))
    if not active_items: return [], 0, 0

    total_pnl = 0
    total_percent = 0
    
    try:
        symbols = [t['symbol'] for t in active_items]
        tickers = exchange.fetch_tickers(symbols)
        
        for trade in active_items:
            sym = trade['symbol']
            if sym in tickers:
                current = tickers[sym]['last']
                entry = float(trade['entry'])
                size = float(trade.get('size', 20.0 / entry if entry > 0 else 0))
                side = trade['side'].upper()

                pnl = (current - entry) * size if side == "LONG" else (entry - current) * size
                p_percent = (pnl / 20.0) * 100 # 20$ Margin bazlı

                trade['current_price'] = current
                trade['pnl'] = round(pnl, 4)
                trade['pnl_percent'] = round(p_percent, 2)
                
                total_pnl += pnl
                total_percent += p_percent
    except Exception as e:
        print(f"Hata: {e}")
    
    return active_items, round(total_pnl, 4), round(total_percent, 2)

def get_history():
    if not os.path.exists("stats.json"): return {}
    with open("stats.json", "r") as f:
        trades = json.load(f)
    daily = defaultdict(lambda: {"pnl": 0, "percent": 0, "count": 0, "trades": []})
    for t in trades:
        d = t.get("date", "Bilinmeyen")
        daily[d]["pnl"] += t.get("pnl", 0)
        daily[d]["percent"] += t.get("percent", 0)
        daily[d]["count"] += 1
        daily[d]["trades"].append(t)
    return dict(sorted(daily.items(), reverse=True))

@app.route('/')
def index():
    active_trades, total_pnl, total_percent = get_live_data()
    return render_template('index.html', 
                           active_trades=active_trades, 
                           total_pnl=total_pnl, 
                           total_percent=total_percent,
                           reports=get_history())

if __name__ == '__main__':
    app.run(debug=True, port=5000)
