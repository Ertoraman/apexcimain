import subprocess
import time
import json
import os
import pymongo
import sys
from datetime import datetime, timedelta

# --- ⚙️ MASTER CONFIG ---
BOT_FILES = [
    "Z_ALGO1 VOLUME PROFILE + PIVOT LEVELS.py",
    "Z_ALGO16 CONFLUENCE SUITE -5 min.py",
    "Z_ALGO20 Z_ALGO1 SPC.py"
]
MAX_INSTANCES = 3
STAGGER_INTERVAL = 600 
COOLDOWN_INTERVAL = 600 
FIXED_MARGIN = 20.0     
STATS_FILE = "stats.json"

class MasterOrchestrator:
    def __init__(self):
        self.active_bots = {}  
        self.cooldowns = []    
        self.processed_ids = set() # Çift kaydı önlemek için
        
        try:
            self.mongo_client = pymongo.MongoClient("mongodb://localhost:27017/", serverSelectionTimeoutMS=2000)
            self.db = self.mongo_client["apexprotocol"]
            self.signals = self.db["signal"]
            print("✅ Master Manager: MongoDB Bağlantısı Kuruldu.")
        except:
            print("❌ HATA: MongoDB'ye ulaşılamıyor!")
            sys.exit()

        if not os.path.exists(STATS_FILE):
            with open(STATS_FILE, "w") as f: json.dump([], f)

    def log_and_calculate(self, record):
        """20$ üzerinden yüzde hesaplar ve JSON'a mühürler"""
        try:
            # Daha önce işlenmişse atla
            rec_id = str(record["_id"])
            if rec_id in self.processed_ids: return False

            pnl = float(record.get("pnl", 0))
            percentage = (pnl / FIXED_MARGIN) * 100
            
            log_entry = {
                "date": datetime.now().strftime("%d.%m.%Y"),
                "full_time": datetime.now().strftime("%H:%M:%S"),
                "symbol": record.get("symbol"),
                "side": record.get("side"),
                "pnl": round(pnl, 4),
                "percent": round(percentage, 2),
                "bot": record.get("pattern", "Z_ALGO_INSTANCE")
            }
            
            # JSON Dosyasını Güvenli Aç/Yaz
            with open(STATS_FILE, "r+") as f:
                data = json.load(f)
                data.append(log_entry)
                f.seek(0)
                json.dump(data, f, indent=4)
            
            self.processed_ids.add(rec_id)
            print(f"📝 JSON KAYIT BAŞARILI: {log_entry['symbol']} | PNL: {pnl}$")
            return True
        except Exception as e:
            print(f"❌ JSON Yazma Hatası: {e}")
            return False

    def start_bot(self, file_name, wave_info=""):
        try:
            proc = subprocess.Popen(
                [sys.executable, file_name],
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            )
            self.active_bots[proc.pid] = {"file": file_name, "proc": proc}
            print(f"🚀 Bot Başlatıldı: {file_name} {wave_info} (PID: {proc.pid})")
        except Exception as e:
            print(f"❌ Başlatma Hatası ({file_name}): {e}")

    def monitor(self):
        # Kademeli Başlatma
        for wave in range(MAX_INSTANCES):
            print(f"\n🌊 {wave+1}. Dalga Başlatılıyor...")
            for bot_file in BOT_FILES:
                self.start_bot(bot_file, f"[{wave+1}. Kopya]")
            if wave < MAX_INSTANCES - 1:
                time.sleep(STAGGER_INTERVAL)

        print("\n🛰️ Gözlem Döngüsü Aktif. Sinyaller Bekleniyor...")
        
        while True:
            try:
                now_ts = time.time()
                
                # 1. Soğuma Süresi Kontrolü
                for cd in self.cooldowns[:]:
                    if now_ts >= cd["ready_at"]:
                        self.start_bot(cd["file"], "[Soğuma Sonrası]")
                        self.cooldowns.remove(cd)

                # 2. MongoDB Taraması (TÜM SİNYALLERİ ÇEKER)
                # Son 1 dakika içindeki tüm CLOSE sinyallerini bul
                search_time = datetime.now() - timedelta(minutes=1)
                close_signals = list(self.signals.find({"action": "CLOSE", "time": {"$gt": search_time}}))

                for sig in close_signals:
                    # JSON'a kaydet (Başarılıysa botu kapat)
                    if self.log_and_calculate(sig):
                        # İlgili bir botu feda et ve soğumaya al
                        for pid, info in list(self.active_bots.items()):
                            info["proc"].terminate()
                            print(f"🛑 Bot Soğumaya Alındı: {info['file']}")
                            self.cooldowns.append({
                                "file": info["file"],
                                "ready_at": time.time() + COOLDOWN_INTERVAL
                            })
                            del self.active_bots[pid]
                            break
                        
                        # MongoDB'den temizle ki bir daha okunmasın
                        self.signals.delete_one({"_id": sig["_id"]})

                time.sleep(5) # 5 saniyede bir kontrol (Daha hassas)
            except Exception as e:
                print(f"⚠️ Döngü Hatası: {e}")
                time.sleep(5)

if __name__ == "__main__":
    MasterOrchestrator().monitor()
