import asyncio
import aiohttp
import time
import hmac
import hashlib
import math
from pymongo import MongoClient
from datetime import datetime, timezone

# =================================================================================
# APEX V100 - YÜKSEK FREKANSLI İŞLEM MOTORU (HFT)
# ÇOKLU BOT VE KISMİ KAPATMA (NO-DUST) DESTEKLİ
# =================================================================================

# --- MOTOR AYARLARI ---
ENGINE_MODE = "HEDGE"  # "HEDGE" veya "ONE_WAY"
# ----------------------

client = MongoClient("mongodb://localhost:27017/")
db = client["apexprotocol"]
users_col = db["users"]
signals_col = db["signal"]
logs_col = db["user_logs"]

# Çoklu Bot Hafıza Koleksiyonu (Hangi bot kaç adet açtı burada tutulur)
active_trades_col = db["active_trades"] 

BINANCE_FAPI_URL = "https://fapi.binance.com"
EXCHANGE_INFO_CACHE = {}
VERIFIED_USERS_MODE = set()  

def get_binance_signature(query_string, secret):
    return hmac.new(secret.encode('utf-8'), query_string.encode('utf-8'), hashlib.sha256).hexdigest()

# 1. BİNANCE HASSASİYET KURALLARI
async def fetch_exchange_info():
    global EXCHANGE_INFO_CACHE
    print(f"[SİSTEM] Binance Borsa Kuralları Çekiliyor... (Aktif Mod: {ENGINE_MODE})")
    async with aiohttp.ClientSession() as session:
        async with session.get(f"{BINANCE_FAPI_URL}/fapi/v1/exchangeInfo") as response:
            if response.status == 200:
                data = await response.json()
                for symbol_data in data['symbols']:
                    sym = symbol_data['symbol']
                    filters = {f['filterType']: f for f in symbol_data['filters']}
                    EXCHANGE_INFO_CACHE[sym] = {
                        'stepSize': float(filters.get('LOT_SIZE', {}).get('stepSize', '0')),
                        'tickSize': float(filters.get('PRICE_FILTER', {}).get('tickSize', '0'))
                    }
                print(f"[SİSTEM] {len(EXCHANGE_INFO_CACHE)} Sembolün Kuralları Hafızaya Alındı.")

def round_step_size(quantity, step_size):
    precision = int(round(-math.log(step_size, 10), 0))
    return float(round(math.floor(quantity / step_size) * step_size, precision))

# 2. HESAP MODU DOĞRULAYICI
async def ensure_position_mode(session, api_key, secret_key, username):
    if username in VERIFIED_USERS_MODE: return True
    headers = {"X-MBX-APIKEY": api_key}
    timestamp = int(time.time() * 1000)
    query = f"timestamp={timestamp}"
    sig = get_binance_signature(query, secret_key)
    
    async with session.get(f"{BINANCE_FAPI_URL}/fapi/v1/positionSide/dual?{query}&signature={sig}", headers=headers) as resp:
        if resp.status == 200:
            data = await resp.json()
            is_hedge_active = data.get("dualSidePosition", False)
            target_hedge = (ENGINE_MODE == "HEDGE")
            
            if is_hedge_active != target_hedge:
                update_val = "true" if target_hedge else "false"
                update_query = f"dualSidePosition={update_val}&timestamp={int(time.time() * 1000)}"
                update_sig = get_binance_signature(update_query, secret_key)
                
                async with session.post(f"{BINANCE_FAPI_URL}/fapi/v1/positionSide/dual?{update_query}&signature={update_sig}", headers=headers) as update_resp:
                    update_data = await update_resp.json()
                    if update_resp.status == 200 and update_data.get("code") == 200:
                        logs_col.insert_one({"username": username, "type": "success", "symbol": "SİSTEM", "message": f"Hesap modunuz {ENGINE_MODE} olarak güncellendi.", "time": datetime.now()})
                    else:
                        logs_col.insert_one({"username": username, "type": "error", "symbol": "SİSTEM", "message": f"Mod Değiştirilemedi: Lütfen açık işlemlerinizi kapatın.", "time": datetime.now()})
                        return False
            VERIFIED_USERS_MODE.add(username)
            return True
        return False

# 3. İŞLEM MOTORU (KİMLİK EŞLEŞTİRMELİ KUSURSUZ HAFIZA)
async def execute_trade_for_user(session, user, signal, symbol):
    api_key = user.get("api_key")
    secret_key = user.get("secret_key")
    username = user.get("username")
    
    if not api_key or not secret_key: return

    mode_ready = await ensure_position_mode(session, api_key, secret_key, username)
    if not mode_ready: return

    try:
        timestamp = int(time.time() * 1000)
        action = signal.get("action", "").upper()
        signal_side = signal.get("side", "").upper() 
        pattern = signal.get("pattern", "UNKNOWN") # İşlemi açan botun strateji adı
        entry_price = float(signal.get("entry", 1)) # İşlemi açan botun kesin giriş fiyatı
        
        headers = {"X-MBX-APIKEY": api_key}
        rules = EXCHANGE_INFO_CACHE.get(symbol)
        if not rules: raise Exception("Borsa kuralları bulunamadı.")
        
        # ------------------------------------------------------------------
        # İŞLEM KAPATMA (Botun Kendi Pozisyonunu Tanıyıp Sadece Onu Kapatması)
        # ------------------------------------------------------------------
        if action.startswith("CLOSE"):
            # 1. Hafızadan tam olarak bu botun açtığı işlemi bul (Kimlik Eşleştirme)
            kayitli_islem = active_trades_col.find_one({
                "username": username,
                "symbol": symbol,
                "side": signal_side,
                "pattern": pattern,
                "entry_price": entry_price
            })

            if kayitli_islem:
                # Botun önceden açtığı noktası virgülüne kesin miktar
                kapatilacak_miktar = float(kayitli_islem["quantity"])
            else:
                # Motor kapalıyken açılmış bir işlemse formülle kurtarma yap
                bakiye_ayari = float(user.get("miktar", 50))
                kapatilacak_miktar = round_step_size(bakiye_ayari / entry_price, rules['stepSize'])

            if kapatilacak_miktar <= 0: return

            # 2. Binance'deki mevcut durumu öğren
            p_params = f"symbol={symbol}&timestamp={int(time.time() * 1000)}"
            p_sig = get_binance_signature(p_params, secret_key)
            
            async with session.get(f"{BINANCE_FAPI_URL}/fapi/v2/positionRisk?{p_params}&signature={p_sig}", headers=headers) as pos_resp:
                pos_data = await pos_resp.json()
                target_position = None
                
                if isinstance(pos_data, list):
                    for pos in pos_data:
                        if ENGINE_MODE == "HEDGE" and pos.get("positionSide") == signal_side:
                            target_position = pos
                            break
                        elif ENGINE_MODE == "ONE_WAY" and pos.get("positionSide") == "BOTH":
                            target_position = pos
                            break

                if target_position:
                    position_amt = float(target_position.get("positionAmt", 0))
                    
                    if position_amt != 0: 
                        abs_amt = abs(position_amt)
                        
                        # TOZ BIRAKMAMA MANTIĞI:
                        # Eğer borsadaki toplam miktar, bizim botun satacağı miktara stepSize kadar yakınsa
                        # (Yani başka botun işlemi kalmamışsa) kalan son küsuratın hepsini (abs_amt) satıp tertemiz yap.
                        # Aksi halde SADECE bu botun miktarı kadar sat, diğer botlara dokunma!
                        if abs_amt <= (kapatilacak_miktar + rules['stepSize']):
                            gercek_kapanis_miktari = abs_amt
                        else:
                            gercek_kapanis_miktari = kapatilacak_miktar

                        if ENGINE_MODE == "HEDGE":
                            close_side = "SELL" if signal_side == "LONG" else "BUY"
                            close_params = f"symbol={symbol}&side={close_side}&positionSide={signal_side}&type=MARKET&quantity={gercek_kapanis_miktari}&timestamp={int(time.time() * 1000)}"
                        else: 
                            close_side = "SELL" if position_amt > 0 else "BUY"
                            close_params = f"symbol={symbol}&side={close_side}&type=MARKET&quantity={gercek_kapanis_miktari}&reduceOnly=true&timestamp={int(time.time() * 1000)}"

                        close_sig = get_binance_signature(close_params, secret_key)
                        
                        async with session.post(f"{BINANCE_FAPI_URL}/fapi/v1/order?{close_params}&signature={close_sig}", headers=headers) as resp:
                            result = await resp.json()
                            if resp.status == 200:
                                pnl_degeri = round(float(signal.get('pnl', 0)), 2)
                                kapanis_nedeni = signal.get('reason', 'KAPATILDI').replace("🎯", "").replace("🛡️", "").strip()
                                
                                logs_col.insert_one({"username": username, "type": "success", "symbol": symbol, "message": f"{pattern} İşlemi Kapatıldı ({gercek_kapanis_miktari} adet). Neden: {kapanis_nedeni} | Bot Kârı: {pnl_degeri}%", "time": datetime.now()})
                                
                                # Başarıyla kapandıysa hafızadan (active_trades_col) sil
                                if kayitli_islem:
                                    active_trades_col.delete_one({"_id": kayitli_islem["_id"]})
                            else:
                                logs_col.insert_one({"username": username, "type": "error", "symbol": symbol, "message": f"Kapatma Hatası: {result.get('msg')}", "time": datetime.now()})
                    else:
                        logs_col.insert_one({"username": username, "type": "success", "symbol": symbol, "message": f"Kapatılacak {signal_side} pozisyonu bulunamadı. ({pattern})", "time": datetime.now()})
                        if kayitli_islem: active_trades_col.delete_one({"_id": kayitli_islem["_id"]})

        # ------------------------------------------------------------------
        # İŞLEM AÇMA (Market Emri + Hafızaya Mühürleme)
        # ------------------------------------------------------------------
        elif action.startswith("OPEN"):
            bakiye_ayari = float(user.get("miktar", 50))
            raw_quantity = bakiye_ayari / entry_price
            final_quantity = round_step_size(raw_quantity, rules['stepSize'])
            
            if final_quantity <= 0: return

            trade_side = "BUY" if signal_side == "LONG" else "SELL"
            
            # 1. ANA MARKET EMRİNİ GÖNDER
            if ENGINE_MODE == "HEDGE":
                main_order_params = f"symbol={symbol}&side={trade_side}&positionSide={signal_side}&type=MARKET&quantity={final_quantity}&timestamp={timestamp}"
            else:
                main_order_params = f"symbol={symbol}&side={trade_side}&type=MARKET&quantity={final_quantity}&timestamp={timestamp}"
                
            main_order_sig = get_binance_signature(main_order_params, secret_key)
            
            async with session.post(f"{BINANCE_FAPI_URL}/fapi/v1/order?{main_order_params}&signature={main_order_sig}", headers=headers) as resp:
                main_data = await resp.json()
                
                if "code" in main_data and main_data["code"] < 0:
                    hata_metni = "Yetersiz Vadeli Bakiye" if "Margin is insufficient" in main_data.get("msg", "") else main_data.get("msg")
                    logs_col.insert_one({"username": username, "type": "error", "symbol": symbol, "message": f"Giriş Reddedildi: {hata_metni}", "time": datetime.now()})
                    return 
                
                # 2. İŞLEMİ KİMLİĞİYLE BERABER HAFIZAYA YAZ
                # Farklı bir bot aynı coine girerse, pattern ve entry farklı olduğu için ayrı bir kayıt olarak durur.
                active_trades_col.insert_one({
                    "username": username,
                    "symbol": symbol,
                    "side": signal_side,
                    "pattern": pattern,
                    "entry_price": entry_price,
                    "quantity": final_quantity,
                    "time": datetime.now()
                })
                
                logs_col.insert_one({"username": username, "type": "success", "symbol": symbol, "message": f"{pattern} sinyaliyle {signal_side} açıldı ({final_quantity} adet).", "time": datetime.now()})

    except Exception as e:
        logs_col.insert_one({"username": username, "type": "error", "symbol": symbol, "message": f"Motor Hatası: {str(e)}", "time": datetime.now()})

# 4. ANA DÖNGÜ (DİNLENİCİ)
async def engine_loop():
    await fetch_exchange_info()
    print("\n[🚀 APEX MOTORU AKTİF] Sinyaller Bekleniyor...\n")
    
    last_processed_id = None
    latest = signals_col.find_one(sort=[("_id", -1)])
    if latest:
        last_processed_id = latest["_id"]

    async with aiohttp.ClientSession() as session:
        while True:
            try:
                query = {"_id": {"$gt": last_processed_id}} if last_processed_id else {}
                new_signals = list(signals_col.find(query).sort("_id", 1))
                
                for signal in new_signals:
                    last_processed_id = signal["_id"]
                    raw_symbol = signal.get("symbol", "")
                    symbol = raw_symbol.split(":")[0].replace("/", "")
                    
                    print(f"\n[⚡ SİNYAL] {symbol} | Yön: {signal.get('side')} | İşlem: {signal.get('action')}")
                    
                    now_utc = datetime.now(timezone.utc)
                    active_users = list(users_col.find({
                        "bot_status": "active",
                        "subscription_end": {"$gt": now_utc}
                    }))
                    
                    tasks = [execute_trade_for_user(session, user, signal, symbol) for user in active_users]
                    if tasks:
                        await asyncio.gather(*tasks)
                    
            except Exception as e:
                print(f"[SİSTEM HATASI] Döngüde hata oluştu: {str(e)}")
            
            await asyncio.sleep(1) 

if __name__ == "__main__":
    import sys
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(engine_loop())
