from pymongo import MongoClient
from datetime import datetime, timezone

# MongoDB bağlantısını kur
client = MongoClient("mongodb://localhost:27017/")
db = client["apexprotocol"]
collection = db["user_logs"]

# Şu anki zamanı alarak bir test verisi oluşturuyoruz
# Not: MongoDB zaman hesaplamalarını en sağlıklı şekilde UTC üzerinden yapar.
test_log = {
    "username": "test_kullanicisi@test.com",
    "type": "info",
    "symbol": "TESTUSDT",
    "message": "Bu bir TTL test mesajıdır. Eklendikten tam 4 saat sonra silinmelidir.",
    "time": datetime.now(timezone.utc)
}

# Veriyi koleksiyona ekle
result = collection.insert_one(test_log)

print("Test kaydı başarıyla eklendi!")
print(f"Kayıt ID'si: {result.inserted_id}")
print(f"Eklenme Zamanı (UTC): {test_log['time']}")
print("\nLütfen MongoDB Compass ekranını açıp 'Refresh' (Yenile) butonuna bas.")
